# Yersinia pestis KIM10+, complete genome

GenBank: AE009952.1

https://www.ncbi.nlm.nih.gov/nuccore/AE009952.1?report=fasta
