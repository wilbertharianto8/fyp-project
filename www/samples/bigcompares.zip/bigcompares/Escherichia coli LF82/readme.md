# Escherichia coli LF82 chromosome, complete sequence

GenBank: CU651637.1

https://www.ncbi.nlm.nih.gov/nuccore/CU651637.1?report=fasta
